<?php
// required headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

include_once '../config/database.php';
include_once '../objects/culture.php';

// instantiate database and product object
$database = new Database();
$db = $database->getConnection();

// initialize object
$cul = new Culture($db);

// query products
$stmt = $cul->read();
$num = $stmt->rowCount();

if($num>0){

  // products array
  $data_arr=array();
  $data_arr['payload']=array();

  // retrieve our table contents
  // fetch is fatster than fetchall(?)
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to $name only

    extract($row);

    $rel_item=array(
      'cul_id' => $cul_id,
      'culture_name' => $culture_name,
	  'cul_type' => $cul_type,
	  
       
    );

    array_push($data_arr['payload'], $rel_item);
  }

  echo json_encode($data_arr);
} else {
  echo json_encode(
    array('message' => 'No data found.')
  );
}
?>
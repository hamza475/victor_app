<?php
class Business{
  
    // database connection and table name
    private $conn;
    private $table_name = "business_photo";
	
    
    //public $id;
    public $bus_photo;
	public $bus_gall;
	
	
	
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function create1(){
	
	//$ImagePath = "path/$bus_photo.jpg";
   // $ServerURL = "http://localhost/away/objects/$ImagePath";

    $query =  "INSERT INTO
                " . $this->table_name . "
      SET    bus_photo=:bus_photo, bus_gall=:bus_gall ";
	//$query = "insert into business_photo (f_name,l_name,selected_school,selected_accomo,selected_course,email,mobile_num,passport_copy) values ('$f_name','$l_name','$selected_school','$selected_accomo','$selected_course','$email','$mobile_num','$ServerURL');";
 

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // sanitize
  
    //$this->id=htmlspecialchars(strip_tags($this->id));
    $this->bus_photo=htmlspecialchars(strip_tags($this->bus_photo));
	$this->bus_gall=htmlspecialchars(strip_tags($this->bus_gall));
	

    // bind values
    
	//$stmt->bindParam(":id", $this->id);
    $stmt->bindParam(":bus_photo", $this->bus_photo);
	$stmt->bindParam(":bus_gall", $this->bus_gall);
  
 
    // execute query
    if($stmt->execute()){
      return true;
    }else{
      return false;
    }
}


}
?>
<?php
class Art{
  
    // database connection and table name
    private $conn;
    private $table_name = "business_cate";
	
    
    public $id;
    public $business_name;
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function read(){
    $query = 'SELECT  id, business_name  FROM business_cate ;';

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();

    return $stmt;
  }
}
?>
<?php
class Culture{
  
    // database connection and table name
    private $conn;
    private $table_name = "culture_idf";
	
    
    public $cul_id;
    public $culture_name;
	public $cul_type;
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function read(){
    $query = 'SELECT  cul_id, culture_name, cul_type  FROM culture_idf ;';

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();

    return $stmt;
  }
}
?>
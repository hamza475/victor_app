<?php
class Login{
  
    // database connection and table name
    private $conn;
    private $table_name = "login_table";

    public $id;
    public $username;
    public $password;
    public $email;
    
	
    
   

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 
function read(){
    $query = 'SELECT  customer_id ,customer_name, customer_email, customer_phone, customer_address, customer_website  FROM add_customer ;';

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();

    return $stmt;
  }
  

 function login_data(){  
  
 $query = 'SELECT * FROM login_table  WHERE username= ? , password=? ;';

  
 // prepare query statement
    $stmt = $this->conn->prepare($query);

    // bind id of product to be updated
    $stmt->bindParam(1, $this->username,password);

    // execute query
    $stmt->execute();

    // get retrieved row
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

       // set values to object properties
	  // $this->id = $row['id'];
	   $this->id = $row['id'];
       $this->username = $row['username'];
       $this->password = $row['password'];
	   $this->email = $row['email'];
	  
	 
	  
}  


 

}


?>
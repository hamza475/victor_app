<?php
class Social{
  
    // database connection and table name
    private $conn;
    private $table_name = "social_links";
	
    
    //public $id;
	public $bus_id;
    public $twitter;
	public $insta;
	public $fb;
	
	
	
	
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function create1(){
    $query =  "INSERT INTO
                " . $this->table_name . "
      SET    bus_id=:bus_id, twitter=:twitter, insta=:insta, fb=:fb ";

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // sanitize
  
    $this->bus_id=htmlspecialchars(strip_tags($this->bus_id));
    $this->twitter=htmlspecialchars(strip_tags($this->twitter));
	$this->insta=htmlspecialchars(strip_tags($this->insta));
	$this->fb=htmlspecialchars(strip_tags($this->fb));

  

    // bind values
    
	$stmt->bindParam(":bus_id", $this->bus_id);
    $stmt->bindParam(":twitter", $this->twitter);
	$stmt->bindParam(":insta", $this->insta);
    $stmt->bindParam(":fb", $this->fb);

  
    // execute query
    if($stmt->execute()){
      return true;
    }else{
      return false;
    }
}


}
?>
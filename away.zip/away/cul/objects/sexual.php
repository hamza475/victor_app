<?php
class Sexual{
  
    // database connection and table name
    private $conn;
    private $table_name = "sexsual_idf";
	
    
    public $id;
    public $sex_name;
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function read(){
    $query = 'SELECT  id, sex_name  FROM sexsual_idf ;';

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // execute query
    $stmt->execute();

    return $stmt;
  }
}
?>
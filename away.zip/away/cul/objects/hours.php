<?php
class Hours{
  
    // database connection and table name
    private $conn;
    private $table_name = "business_hours";
	
    
    //public $id;
    public $day;
	public $day_enabled;
	public $start_time;
	public $end_time;
	public $bus_id;
	
	
	
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function create(){
    $query =  "INSERT INTO
                " . $this->table_name . "
      SET   day=:day, day_enabled=:day_enabled, start_time=:start_time, end_time=:end_time, bus_id=:bus_id ";

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // sanitize
  
    //$this->id=htmlspecialchars(strip_tags($this->id));
    $this->day=htmlspecialchars(strip_tags($this->day));
	$this->day_enabled=htmlspecialchars(strip_tags($this->day_enabled));
	$this->start_time=htmlspecialchars(strip_tags($this->start_time));
	$this->end_time=htmlspecialchars(strip_tags($this->end_time));
    $this->bus_id=htmlspecialchars(strip_tags($this->bus_id));
	
	
	
   



    // bind values
    
	//$stmt->bindParam(":id", $this->id);
    $stmt->bindParam(":day", $this->day);
	$stmt->bindParam(":day_enabled", $this->day_enabled);
    $stmt->bindParam(":start_time", $this->start_time);
	$stmt->bindParam(":end_time", $this->end_time);
	$stmt->bindParam(":bus_id", $this->bus_id);
	
	
  
    // execute query
    if($stmt->execute()){
      return true;
    }else{
      return false;
    }
}

}
?>
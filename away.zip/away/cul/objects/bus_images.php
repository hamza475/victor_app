
<?php
 header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

  
include 'DatabaseConfig.php' ;

 
$return_arr = array();
 
// Create connection
 $conn =  mysqli_connect($HostName,$HostUser,$HostPass,$DatabaseName);
 


 
 $DefaultId = 0;
 $ImageData =  isset($_POST["bus_photo"]);
 
 //$bus_photo =isset($_POST["bus_photo"]);
 $bus_gall =  isset($_POST["bus_gall"]);
 


 $GetOldIdSQL ="SELECT businessphoto_id FROM  business_photo ORDER BY businessphoto_id ASC";
 
 $query = mysqli_query($conn,$GetOldIdSQL);
 
 while($row = mysqli_fetch_array($query)){
 
 $DefaultId = $row['businessphoto_id'];
 }
 
 

 
 $ImagePath = "path/$DefaultId.jpg";
 
 $ServerURL = "http://localhost/away/objects/$ImagePath";

 
 $Sql_Query = "insert into business_photo (bus_photo, bus_gall) values ('$ServerURL', '$bus_gall');";
 
 if(mysqli_query($conn, $Sql_Query)){
  file_put_contents($ImagePath,base64_decode($ImageData));
 $decodeString = convert_uudecode($bus_gall);
  echo $decodeString;

 


   $row_array['errorcode1'] = 1;

 }else{
 echo "Please Try Again";
 }

 
?>
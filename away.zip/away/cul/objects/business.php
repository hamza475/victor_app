<?php
class Business{
  
    // database connection and table name
    private $conn;
    private $table_name = "business_create";
	
    
    //public $id;
    public $first_name;
	public $last_name;
	public $email;
	public $password;
	public $businessNme;
	public $phone;
	public $website;
	public $address;
	public $short_des;
	public $business_cateid;
	public $business_email;
	
	
    
  
	

  // constructor with $db as database connection
  public function __construct($db){
    $this->conn = $db;
  }
 

function create(){
    $query =  "INSERT INTO
                " . $this->table_name . "
      SET   first_name=:first_name, last_name=:last_name, email=:email, password=:password, businessNme=:businessNme, phone=:phone, website=:website, address=:address, short_des=:short_des, business_cateid=:business_cateid, business_email=:business_email ";

    // prepare query statement
    $stmt = $this->conn->prepare($query);

    // sanitize
  
    //$this->id=htmlspecialchars(strip_tags($this->id));
    $this->first_name=htmlspecialchars(strip_tags($this->first_name));
	$this->last_name=htmlspecialchars(strip_tags($this->last_name));
	$this->email=htmlspecialchars(strip_tags($this->email));
	$this->password=htmlspecialchars(strip_tags($this->password));
    $this->businessNme=htmlspecialchars(strip_tags($this->businessNme));
	$this->phone=htmlspecialchars(strip_tags($this->phone));
	$this->website=htmlspecialchars(strip_tags($this->website));
	$this->address=htmlspecialchars(strip_tags($this->address));
	$this->short_des=htmlspecialchars(strip_tags($this->short_des));
    $this->business_cateid=htmlspecialchars(strip_tags($this->business_cateid));
	$this->business_email=htmlspecialchars(strip_tags($this->business_email));
	
	
	
   



    // bind values
    
	//$stmt->bindParam(":id", $this->id);
    $stmt->bindParam(":first_name", $this->first_name);
	$stmt->bindParam(":last_name", $this->last_name);
    $stmt->bindParam(":email", $this->email);
	$stmt->bindParam(":businessNme", $this->businessNme);
	$stmt->bindParam(":phone", $this->phone);
	$stmt->bindParam(":website", $this->website);
	$stmt->bindParam(":address", $this->address);
	$stmt->bindParam(":short_des", $this->short_des);
	$stmt->bindParam(":business_cateid", $this->business_cateid);
    $stmt->bindParam(":business_email", $this->business_email);	
 // hash the password before saving to database
    $password_hash = password_hash($this->password, PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password_hash);
	
  
    // execute query
    if($stmt->execute()){
      return true;
    }else{
      return false;
    }
}

}
?>
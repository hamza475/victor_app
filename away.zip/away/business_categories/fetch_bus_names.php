<?php
// required headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

include_once '../config/database.php';
include_once '../objects/business_cat.php';

// instantiate database and product object
$database = new Database();
$db = $database->getConnection();

// initialize object
$art = new Art($db);

// query products
$stmt = $art->read();
$num = $stmt->rowCount();

if($num>0){

  // products array
  $data_arr=array();
  $data_arr['payload']=array();

  // retrieve our table contents
  // fetch is fatster than fetchall(?)
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to $name only

    extract($row);

    $rel_item=array(
      'id' => $id,
      'business_name' => $business_name,
       
    );

    array_push($data_arr['payload'], $rel_item);
  }

  echo json_encode($data_arr);
} else {
  echo json_encode(
    array('message' => 'No data found.')
  );
}
?>
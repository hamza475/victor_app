<?php
// required headers
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');

include_once '../config/database.php';
include_once '../objects/religion.php';

// instantiate database and product object
$database = new Database();
$db = $database->getConnection();

// initialize object
$religion = new Religion($db);

// query products
$stmt = $religion->read();
$num = $stmt->rowCount();

if($num>0){

  // products array
  $data_arr=array();
  $data_arr['records']=array();

  // retrieve our table contents
  // fetch is fatster than fetchall(?)
  while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
    // extract row
    // this will make $row['name'] to $name only

    extract($row);

    $rel_item=array(
      'id' => $id,
      'rel_name' => $rel_name,
       
    );

    array_push($data_arr['records'], $rel_item);
  }

  echo json_encode($data_arr);
} else {
  echo json_encode(
    array('message' => 'No data found.')
  );
}
?>
<?php

$DBhost = "34.134.250.9";
$DBuser = "root";
$DBpassword ="Ahsan@786";
$DBname="victor";

$conn = mysqli_connect($DBhost, $DBuser, $DBpassword, $DBname); 

if(!$conn){
	die("Connection failed: " . mysqli_connect_error());
}

?> 
<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json; charset=UTF-8');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Max-Age: 3600');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With');

// get database connection
include_once '../config/database.php';

// instantiate product object
include_once '../objects/hours.php';

$database = new Database();
$db = $database->getConnection();

$business_h = new Hours($db);

// get posted data
$data = json_decode(file_get_contents('php://input'), false);


if(
   
    !empty($data->day) &&
    !empty($data->day_enabled)
   
   
){
  
    // set product property values
//$business->id = $data->id;
$business_h->day = $data->day;
$business_h->day_enabled = $data->day_enabled;
$business_h->start_time = $data->start_time;
$business_h->end_time = $data->end_time;
$business_h->bus_id = $data->bus_id;
  
    // create the product
    if($business_h->create()){
  
        // set response code - 201 created
        http_response_code(200);
  
        // tell the user
		   $size = 10;
            $p = 0;
			$myarray = array();
			while($p < $size) {
             $myarray[] = array(
			 "day" => $data->day,
			  "day_enabled" => $data->day_enabled,
			  "start_time" => $data->start_time,
			  "end_time" => $data->end_time
			  );
             $p++;
                }
			 
		 echo json_encode(array("status" => true,
		"description" => "Busines Hours Register Successfully",
		 "payload" => array(
		    "bus_id" => $data->bus_id,
			"days" => $myarray[]
            
			
			  
			//"days" => $days
			
		    
		 
				
       )
	   
		));
        //echo json_encode(array("message" => "User was created."));
    }
  
    // if unable to create the product, tell the user
    else{
  
        // set response code - 503 service unavailable
        http_response_code(503);
  
        echo json_encode(array("status" => false,
		"description" => "Email already exisit ",
		 "payload" => array(
               
       )
		));
    }
}
  
// tell the user data is incomplete
else{
  
    // set response code - 400 bad request
    http_response_code(400);
  
    // tell the user
    echo json_encode(array("message" => "Unable to create User. Data is incomplete."));
}


?>